import React from 'react';
import { ArrowRight } from 'lucide-react';

interface NeonButtonProps {
  text: string;
  onClick?: () => void;
  className?: string;
  fullWidth?: boolean;
}

const NeonButton: React.FC<NeonButtonProps> = ({ text, onClick, className = '', fullWidth = false }) => {
  return (
    <button
      onClick={onClick}
      className={`
        relative group overflow-hidden bg-neon-green text-black font-black uppercase tracking-wider
        py-4 px-8 rounded-sm transition-all duration-300 transform hover:scale-[1.02]
        shadow-[0_0_20px_rgba(57,255,20,0.4)] hover:shadow-[0_0_40px_rgba(57,255,20,0.6)]
        border-2 border-neon-green flex items-center justify-center gap-2
        ${fullWidth ? 'w-full' : ''}
        ${className}
      `}
    >
      <span className="relative z-10 font-display text-xl md:text-2xl">{text}</span>
      <ArrowRight className="w-6 h-6 relative z-10 group-hover:translate-x-1 transition-transform" strokeWidth={3} />
      
      {/* Shine effect overlay */}
      <div className="absolute inset-0 -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/40 to-transparent z-0 w-full h-full" />
    </button>
  );
};

export default NeonButton;