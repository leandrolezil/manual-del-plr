import React from 'react';
import { Star } from 'lucide-react';
import { Testimonial } from '../types';

const testimonials: Testimonial[] = [
  { id: 1, name: "Carlos M.", role: "Ex-Dropshipper", image: "https://picsum.photos/100/100?random=1", quote: "Dejé el dropshipping porque los márgenes eran basura. Con PLR, el margen es 100%. Hice mis primeros $1k en 4 días.", rating: 5 },
  { id: 2, name: "Ana Sofia R.", role: "Estudiante", image: "https://picsum.photos/100/100?random=2", quote: "No quería salir en cámara. El Sistema Fantasma es real. Mis padres no saben qué hago, solo ven que invito las cenas.", rating: 5 },
  { id: 3, name: "Jorge L.", role: "Marketer", image: "https://picsum.photos/100/100?random=3", quote: "La calidad de los PLR en la bóveda es otro nivel. No es la basura traducida con Google Translate que venden por ahí.", rating: 5 },
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-20 bg-brand-navy relative">
      <div className="max-w-6xl mx-auto px-4 relative z-10">
        <h2 className="text-center font-display text-4xl text-white mb-12">
          RESULTADOS DE LA <span className="text-neon-green">COMUNIDAD</span>
        </h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t) => (
            <div key={t.id} className="bg-black/40 border border-white/5 p-6 rounded-2xl backdrop-blur-sm hover:bg-black/60 transition-colors">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-brand-gold fill-brand-gold" />
                ))}
              </div>
              <p className="text-gray-300 italic mb-6">"{t.quote}"</p>
              <div className="flex items-center gap-4">
                <img src={t.image} alt={t.name} className="w-12 h-12 rounded-full border border-neon-green/30" />
                <div>
                  <h4 className="text-white font-bold text-sm">{t.name}</h4>
                  <p className="text-neon-green text-xs uppercase tracking-wide">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;