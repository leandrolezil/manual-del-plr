import React from 'react';
import { X, TrendingDown, AlertTriangle } from 'lucide-react';

const Problem: React.FC = () => {
  return (
    <section className="py-16 md:py-20 bg-brand-navy relative overflow-hidden border-b border-white/5">
       <div className="absolute inset-0 bg-[url('https://picsum.photos/1920/1080?blur=10')] opacity-5 bg-cover bg-center mix-blend-overlay"></div>
      
      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="font-display text-3xl md:text-5xl text-white mb-4 md:mb-6 uppercase leading-tight">
            ¿Cansado de <span className="text-red-500 line-through decoration-2 md:decoration-4 decoration-red-600">Intentarlo Todo</span>?
          </h2>
          <p className="text-lg md:text-xl text-gray-300">
            Trading, Dropshipping, Crypto... El cementerio de las promesas vacías.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
          {/* Image Side */}
          <div className="relative group order-first md:order-none">
            <div className="absolute -inset-2 bg-gradient-to-r from-red-600 to-purple-600 rounded-lg blur opacity-25 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
            <div className="relative rounded-lg overflow-hidden border border-red-900/50 bg-black h-64 md:h-full aspect-square md:aspect-auto">
              <img 
                src="https://picsum.photos/600/600?grayscale" 
                alt="Frustrated user" 
                className="w-full h-full object-cover opacity-60 mix-blend-luminosity"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <X className="w-32 h-32 md:w-48 md:h-48 text-red-600 opacity-40" strokeWidth={1} />
              </div>
            </div>
          </div>

          {/* Text Side */}
          <div className="space-y-6 md:space-y-8">
            <div className="flex gap-4 items-start">
              <div className="bg-red-500/10 p-3 rounded-lg border border-red-500/20 flex-shrink-0">
                <TrendingDown className="w-6 h-6 md:w-8 md:h-8 text-red-500" />
              </div>
              <div>
                <h3 className="text-lg md:text-xl font-bold text-white mb-2">El Ciclo de la Muerte</h3>
                <p className="text-sm md:text-base text-gray-400">Compras curso tras curso. Te prometen libertad, pero solo encuentras más esclavitud frente a la pantalla, gráficos complicados y márgenes ridículos.</p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="bg-red-500/10 p-3 rounded-lg border border-red-500/20 flex-shrink-0">
                <AlertTriangle className="w-6 h-6 md:w-8 md:h-8 text-red-500" />
              </div>
              <div>
                <h3 className="text-lg md:text-xl font-bold text-white mb-2">La Mentira del "Experto"</h3>
                <p className="text-sm md:text-base text-gray-400">Te dicen que necesitas construir una "Marca Personal". Falso. Los que más facturan en Brasil son fantasmas. Nadie sabe quiénes son.</p>
              </div>
            </div>
            
            <div className="bg-white/5 border-l-4 border-red-500 p-4 md:p-6 italic text-sm md:text-base text-gray-300">
              "No es tu culpa. El sistema está diseñado para venderte el sueño del influencer, no el negocio del empresario."
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Problem;