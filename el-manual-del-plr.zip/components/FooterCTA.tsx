import React, { useState, useEffect } from 'react';
import NeonButton from './ui/NeonButton';

const FooterCTA: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({ minutes: 14, seconds: 59 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds === 0) {
          if (prev.minutes === 0) return { minutes: 14, seconds: 59 }; // Reset for demo loop
          return { minutes: prev.minutes - 1, seconds: 59 };
        }
        return { ...prev, seconds: prev.seconds - 1 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-16 md:py-24 bg-gradient-to-t from-black to-brand-navy text-center border-t border-neon-green/20 relative overflow-hidden">
      <div className="absolute inset-0 bg-cyber-grid bg-[size:30px_30px] opacity-10 pointer-events-none"></div>
      
      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <div className="inline-block bg-red-900/20 border border-red-500/50 px-5 py-2 md:px-6 md:py-2 rounded-full mb-6 md:mb-8 animate-pulse">
           <span className="text-red-500 font-mono text-lg md:text-xl font-bold tracking-widest">
             {String(timeLeft.minutes).padStart(2, '0')}:{String(timeLeft.seconds).padStart(2, '0')}
           </span>
        </div>
        
        <h2 className="font-display text-4xl sm:text-5xl md:text-7xl text-white mb-4 md:mb-6 uppercase leading-none">
          ¿Estás Dentro o <br/> <span className="text-gray-600">Fuera?</span>
        </h2>
        
        <p className="text-gray-300 text-base md:text-lg mb-8 md:mb-10 max-w-xl mx-auto px-4">
          El precio subirá en cuanto el contador llegue a cero. No dejes que la procrastinación te cueste otros $950 dólares.
        </p>

        <div className="px-2">
            <NeonButton 
            text="ASEGURAR MI CUPO AHORA" 
            className="w-full md:w-auto text-lg md:text-2xl px-8 py-5 md:px-12 md:py-6 shadow-[0_0_50px_rgba(57,255,20,0.4)]"
            onClick={() => document.getElementById('offer')?.scrollIntoView({ behavior: 'smooth' })}
            />
        </div>

        <div className="mt-10 md:mt-12 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-gray-600 text-xs gap-4">
           <p>© 2024 El Manual Del PLR. Todos los derechos reservados.</p>
           <div className="flex gap-4">
              <span className="hover:text-white cursor-pointer transition-colors">Términos</span>
              <span className="hover:text-white cursor-pointer transition-colors">Privacidad</span>
              <span className="hover:text-white cursor-pointer transition-colors">Soporte</span>
           </div>
        </div>
      </div>
    </section>
  );
};

export default FooterCTA;