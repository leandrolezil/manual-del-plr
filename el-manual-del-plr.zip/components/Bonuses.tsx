import React from 'react';
import { MessageCircle, Image, Layout } from 'lucide-react';
import { Bonus } from '../types';

const bonuses: Bonus[] = [
  {
    title: "Pack de Creativos Virales",
    description: "100+ Vídeos de stock libres de derechos para tus anuncios en TikTok y Reels.",
    value: "$197",
    imageAlt: "Creativos",
  },
  {
    title: "Scripts de WhatsApp Close",
    description: "Cómo cerrar ventas manuales cuando el cliente duda. Copia y pega.",
    value: "$147",
    imageAlt: "WhatsApp",
  },
  {
    title: "Lista de Nichos Black",
    description: "Los 10 nichos más rentables y menos explorados del 2024.",
    value: "$97",
    imageAlt: "Nichos",
  },
];

const Bonuses: React.FC = () => {
  return (
    <section className="py-16 md:py-20 bg-brand-black border-t border-b border-white/10">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-center font-display text-3xl md:text-5xl text-white mb-12 md:mb-16 uppercase leading-tight">
          Bonos <span className="text-brand-gold">Exclusivos</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-8">
          {bonuses.map((bonus, idx) => (
            <div key={idx} className="relative group">
              {/* Gold Banner */}
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-yellow-600 to-yellow-400 text-black font-bold text-[10px] md:text-xs px-4 py-1 rounded-full z-20 shadow-[0_0_10px_#FFD700] tracking-wider uppercase whitespace-nowrap">
                Bonus Gratuito #{idx + 1}
              </div>

              <div className="bg-[#0f1115] border border-gray-800 rounded-xl p-6 pt-10 md:p-8 md:pt-12 hover:border-brand-gold/50 transition-colors h-full flex flex-col items-center text-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-brand-gold/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                
                <div className="w-20 h-20 md:w-24 md:h-24 bg-gray-900 rounded-lg mb-4 md:mb-6 flex items-center justify-center border border-gray-700 shadow-lg group-hover:scale-105 transition-transform duration-300">
                    {idx === 0 && <Image className="w-8 h-8 md:w-10 md:h-10 text-white" />}
                    {idx === 1 && <MessageCircle className="w-8 h-8 md:w-10 md:h-10 text-white" />}
                    {idx === 2 && <Layout className="w-8 h-8 md:w-10 md:h-10 text-white" />}
                </div>

                <h3 className="text-lg md:text-xl font-bold text-white mb-2 md:mb-3">{bonus.title}</h3>
                <p className="text-gray-400 text-sm mb-4 md:mb-6 flex-grow leading-relaxed">{bonus.description}</p>
                
                <div className="mt-auto pt-4 border-t border-gray-800 w-full">
                  <span className="text-xs text-gray-500 uppercase mr-2">Valor:</span>
                  <span className="text-brand-gold font-bold line-through decoration-red-500">{bonus.value}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Bonuses;