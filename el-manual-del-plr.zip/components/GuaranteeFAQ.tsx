import React, { useState } from 'react';
import { ShieldCheck, Plus, Minus } from 'lucide-react';
import { FaqItem } from '../types';

const faqs: FaqItem[] = [
  { question: "¿Necesito experiencia previa?", answer: "No. El manual está diseñado para llevarte de 0 a 100. Cubrimos desde lo técnico hasta lo estratégico." },
  { question: "¿Tengo que saber inglés?", answer: "No. Enseñamos cómo usar IA para traducir y adaptar todo el contenido al español neutro automáticamente." },
  { question: "¿Necesito mucha inversión para anuncios?", answer: "Puedes empezar con $5-$10 dólares al día usando nuestra estrategia de validación low-ticket." },
  { question: "¿Cuánto tiempo tengo acceso?", answer: "El acceso es de por vida, incluyendo todas las actualizaciones futuras del manual." },
];

const GuaranteeFAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="py-16 md:py-24 bg-brand-black">
      <div className="max-w-4xl mx-auto px-4">
        
        {/* Guarantee Badge */}
        <div className="bg-gradient-to-br from-gray-900 to-black border border-brand-gold p-6 md:p-8 rounded-2xl flex flex-col md:flex-row items-center gap-6 md:gap-8 mb-16 md:mb-20 shadow-[0_0_20px_rgba(255,215,0,0.1)]">
          <div className="flex-shrink-0">
             <ShieldCheck className="w-16 h-16 md:w-24 md:h-24 text-brand-gold" strokeWidth={1} />
          </div>
          <div className="text-center md:text-left">
            <h3 className="text-xl md:text-2xl font-bold text-white mb-2 md:mb-3 font-display uppercase tracking-wide">Garantía Blindada de 7 Días</h3>
            <p className="text-gray-400 text-sm md:text-base leading-relaxed">
              Entra, mira el contenido, descarga los recursos. Si sientes que esto no es para ti, envíanos un email y te devolvemos el 100% de tu dinero. Sin preguntas incómodas. El riesgo es todo nuestro.
            </p>
          </div>
        </div>

        {/* FAQ */}
        <h2 className="text-3xl md:text-5xl font-display text-white text-center mb-8 md:mb-12 uppercase leading-tight">Preguntas Frecuentes</h2>
        <div className="space-y-3 md:space-y-4">
          {faqs.map((faq, idx) => (
            <div key={idx} className="border border-gray-800 rounded-lg bg-gray-900/30 overflow-hidden">
              <button 
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                className="w-full flex items-center justify-between p-5 md:p-6 text-left hover:bg-gray-800/50 transition-colors gap-4"
              >
                <span className="font-bold text-white text-base md:text-lg leading-snug">{faq.question}</span>
                {openIndex === idx ? (
                  <Minus className="text-neon-green w-5 h-5 flex-shrink-0" />
                ) : (
                  <Plus className="text-neon-green w-5 h-5 flex-shrink-0" />
                )}
              </button>
              {openIndex === idx && (
                <div className="p-5 md:p-6 pt-0 text-gray-400 text-sm md:text-base leading-relaxed border-t border-gray-800/50">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

export default GuaranteeFAQ;