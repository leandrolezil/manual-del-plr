import React from 'react';
import { CheckCircle2, Star } from 'lucide-react';
import { ProductModule } from '../types';

const modules: ProductModule[] = [
  { number: 1, title: "La Bóveda Secreta", description: "Acceso a las 50 mejores ofertas PLR de 2024 listas para vender." },
  { number: 2, title: "Traducción Neuronal", description: "Prompts de IA para traducir y mejorar infoproductos en minutos." },
  { number: 3, title: "Estructuras de VSL", description: "Guiones palabra por palabra que hipnotizan a la audiencia." },
  { number: 4, title: "Facebook Ads Black", description: "Estrategias de contingencia para que nunca te baneen." },
  { number: 5, title: "La Página de Ventas Perfecta", description: "Templates JSON para Elementor de alta conversión." },
  { number: 6, title: "Email Marketing Lethal", description: "Secuencias de correo para recuperar carritos abandonados." },
  { number: 7, title: "Upsell & Downsell Mastery", description: "Cómo duplicar el valor de cada cliente automáticamente." },
];

const ProductStack: React.FC = () => {
  return (
    <section id="offer" className="py-16 md:py-24 bg-gradient-to-b from-brand-black to-brand-navy relative">
      <div className="max-w-5xl mx-auto px-4">
        
        <div className="text-center mb-12 md:mb-16">
          <h2 className="font-display text-4xl sm:text-5xl md:text-7xl text-white mb-2 gold-glow">
            EL MANUAL DEL PLR
          </h2>
          <p className="text-xl md:text-2xl text-neon-green tracking-widest font-bold uppercase">Edición Definitiva</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-16">
          {/* Visual Stack Representation */}
          <div className="relative flex justify-center items-center py-8 md:py-0">
             <div className="absolute inset-0 bg-neon-green/20 blur-3xl rounded-full scale-75 md:scale-100"></div>
             <div className="relative z-10 w-full max-w-[320px] md:max-w-none transform rotate-1 hover:rotate-0 transition-transform duration-500">
                {/* Simulated Covers */}
                {[1, 2, 3].map((i) => (
                  <div 
                    key={i} 
                    className="bg-black border border-gray-700 rounded-lg p-3 md:p-4 flex items-center gap-4 shadow-xl mb-[-40px] last:mb-0 relative"
                    style={{ transform: `translateX(${i * 10}px) translateY(-${i * 5}px)` }}
                  >
                     <div className="w-12 h-16 md:w-16 md:h-20 bg-gradient-to-br from-gray-800 to-black border border-brand-gold/50 flex items-center justify-center flex-shrink-0">
                        <span className="text-xl md:text-2xl">📚</span>
                     </div>
                     <div>
                        <div className="h-2 w-16 md:w-24 bg-gray-700 rounded mb-2"></div>
                        <div className="h-2 w-12 md:w-16 bg-gray-800 rounded"></div>
                     </div>
                  </div>
                ))}
                <div className="bg-gradient-to-r from-gray-900 to-black border-2 border-brand-gold rounded-xl p-4 md:p-6 shadow-[0_0_30px_rgba(255,215,0,0.15)] flex flex-col items-center text-center mt-12 md:mt-16 relative z-20">
                  <div className="text-brand-gold font-display text-xl md:text-2xl mb-1 md:mb-2">ACCESO TOTAL</div>
                  <div className="text-gray-400 text-xs md:text-sm">7 Módulos + 3 Bonos</div>
                </div>
             </div>
          </div>

          {/* Module List */}
          <div className="space-y-3 md:space-y-4">
            {modules.map((mod) => (
              <div key={mod.number} className="flex gap-3 md:gap-4 p-3 md:p-4 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors">
                <div className="flex-shrink-0 mt-1">
                  <CheckCircle2 className="w-5 h-5 md:w-6 md:h-6 text-neon-green" />
                </div>
                <div>
                  <h4 className="text-white font-bold text-base md:text-lg mb-1 leading-tight">Módulo {mod.number}: {mod.title}</h4>
                  <p className="text-gray-400 text-xs md:text-sm leading-relaxed">{mod.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Price Anchor */}
        <div className="bg-black/80 border border-brand-gold/30 rounded-2xl p-6 md:p-12 text-center max-w-3xl mx-auto backdrop-blur-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 bg-brand-gold text-black font-bold text-[10px] md:text-xs px-3 py-1 uppercase">Oferta Limitada</div>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-12 mb-6 md:mb-8 mt-4 md:mt-0">
             <div className="text-center opacity-50 grayscale flex md:block items-baseline gap-2">
                <p className="text-base md:text-lg text-gray-400 uppercase tracking-widest mb-1">Valor Real</p>
                <p className="text-3xl md:text-4xl font-display text-gray-500 line-through decoration-red-500 decoration-2">$997</p>
             </div>
             <div className="hidden md:block w-px h-16 bg-gray-700"></div>
             <div className="text-center scale-110">
                <p className="text-sm md:text-lg text-neon-green uppercase tracking-widest mb-1 font-bold">Hoy Solo</p>
                <p className="text-6xl md:text-7xl font-display text-white gold-glow">$47</p>
             </div>
          </div>

          <button className="w-full bg-neon-green hover:bg-green-400 text-black font-black text-lg md:text-2xl py-4 md:py-6 rounded shadow-[0_0_25px_#39FF14] hover:shadow-[0_0_40px_#39FF14] transition-all transform hover:-translate-y-1 uppercase tracking-widest mb-4">
             Obtener Acceso Ahora
          </button>
          
          <div className="flex flex-col sm:flex-row justify-center gap-2 items-center text-gray-400 text-xs uppercase tracking-wider">
             <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-brand-gold fill-brand-gold" />
                <span>Garantía de Satisfacción</span>
                <Star className="w-4 h-4 text-brand-gold fill-brand-gold" />
             </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default ProductStack;