import React from 'react';
import { Play } from 'lucide-react';
import NeonButton from './ui/NeonButton';

const Hero: React.FC = () => {
  return (
    <section className="relative w-full min-h-screen bg-brand-black flex flex-col items-center pt-8 pb-12 md:pb-16 px-4 overflow-hidden border-b border-white/10">
      
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-brand-navy/50 via-brand-black to-brand-black opacity-60 z-0"></div>
      <div className="absolute inset-0 bg-cyber-grid bg-[size:40px_40px] opacity-20 z-0 pointer-events-none"></div>

      {/* Content Container */}
      <div className="relative z-10 max-w-5xl w-full flex flex-col items-center text-center space-y-6 md:space-y-8">
        
        {/* Logo */}
        <div className="opacity-80 mb-2 md:mb-4">
          <span className="text-xs md:text-sm lg:text-base tracking-[0.2em] md:tracking-[0.3em] text-gray-400 font-bold border border-gray-700 px-3 py-1 rounded-full uppercase">
            El Manual Del PLR
          </span>
        </div>

        {/* Headlines */}
        <h1 className="font-display text-4xl sm:text-5xl md:text-7xl lg:text-8xl leading-[0.95] md:leading-[0.9] text-white uppercase tracking-tight">
          El Código <span className="text-neon-green glow-text block md:inline">Brasileño</span>{' '}
          <br className="hidden md:block" />
          Revelado <span className="text-3xl md:text-6xl align-top">🇧🇷</span>
        </h1>

        <p className="text-gray-300 text-base sm:text-lg md:text-2xl max-w-3xl font-light px-2">
          Descubre el <span className="text-white font-bold">"Sistema Fantasma"</span> que los top players de Brasil están usando para generar 
          <span className="text-brand-gold font-bold"> 6 cifras mensuales</span> sin mostrar el rostro y sin crear contenido.
        </p>

        {/* VSL Player Placeholder */}
        <div className="w-full max-w-4xl aspect-video bg-gray-900 rounded-lg border-2 border-neon-green shadow-[0_0_30px_rgba(57,255,20,0.2)] relative group cursor-pointer mt-4 md:mt-6 mb-6 md:mb-8 overflow-hidden">
          <img 
            src="https://picsum.photos/1280/720?grayscale" 
            alt="Video Thumbnail" 
            className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity duration-300"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 md:w-24 md:h-24 bg-neon-green/90 rounded-full flex items-center justify-center pl-1 md:pl-2 shadow-[0_0_20px_#39FF14] group-hover:scale-110 transition-transform duration-300">
              <Play fill="black" className="w-8 h-8 md:w-12 md:h-12 text-black" />
            </div>
          </div>
          <div className="absolute bottom-3 left-3 md:bottom-4 md:left-4 bg-black/80 px-2 md:px-3 py-1 text-[10px] md:text-xs text-white uppercase tracking-widest border-l-2 border-neon-green">
            Ver video completo
          </div>
        </div>

        {/* CTA */}
        <div className="w-full flex flex-col items-center space-y-4 px-2">
          <NeonButton 
            text="Quiero Acceso Inmediato" 
            className="w-full sm:w-auto md:min-w-[400px] text-lg md:text-xl"
            onClick={() => document.getElementById('offer')?.scrollIntoView({ behavior: 'smooth' })}
          />
          <p className="text-[10px] md:text-xs text-gray-500 uppercase tracking-widest flex items-center gap-2 text-center">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse flex-shrink-0"></span>
            Plazas limitadas para esta generación
          </p>
        </div>

      </div>
    </section>
  );
};

export default Hero;