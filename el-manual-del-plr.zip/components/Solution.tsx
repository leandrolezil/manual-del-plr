import React from 'react';
import { Globe, Zap, Database, Lock, ArrowDown } from 'lucide-react';

const Solution: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-black relative overflow-hidden">
      {/* Matrix-like background effect */}
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(0, 255, 0, .3) 25%, rgba(0, 255, 0, .3) 26%, transparent 27%, transparent 74%, rgba(0, 255, 0, .3) 75%, rgba(0, 255, 0, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(0, 255, 0, .3) 25%, rgba(0, 255, 0, .3) 26%, transparent 27%, transparent 74%, rgba(0, 255, 0, .3) 75%, rgba(0, 255, 0, .3) 76%, transparent 77%, transparent)', backgroundSize: '50px 50px' }}></div>
      
      <div className="max-w-6xl mx-auto px-4 relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <span className="text-neon-blue font-bold tracking-widest uppercase text-xs md:text-sm mb-2 block">El Mecanismo</span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-white mb-4">
            El Sistema <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-neon-green to-white animate-pulse">Fantasma</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto">
            Importado directamente de los masterminds más exclusivos de São Paulo.
          </p>
        </div>

        {/* The Graphic Representation */}
        <div className="relative bg-gray-900/50 rounded-2xl border border-white/10 p-6 md:p-12 mb-12 md:mb-16">
          {/* Animated connection lines simulation (Desktop) */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-1 bg-gradient-to-r from-transparent via-neon-green to-transparent opacity-20 transform -translate-y-1/2"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-8 items-center text-center">
            
            {/* Step 1 */}
            <div className="flex flex-col items-center group relative z-10">
              <div className="w-16 h-16 md:w-20 md:h-20 bg-black rounded-full border-2 border-neon-blue shadow-[0_0_15px_#00F0FF] flex items-center justify-center mb-4 md:mb-6 group-hover:scale-110 transition-transform">
                <Globe className="w-8 h-8 md:w-10 md:h-10 text-neon-blue" />
              </div>
              <h3 className="text-white font-bold text-lg md:text-xl mb-2">1. Mercado Global</h3>
              <p className="text-sm text-gray-400 px-4 md:px-0">Identificamos ofertas validadas en EE.UU.</p>
            </div>

            {/* Connection Arrow (Mobile visible, Desktop hidden) */}
            <div className="flex md:hidden justify-center -my-4">
               <ArrowDown className="w-8 h-8 text-neon-green animate-bounce" />
            </div>

            {/* Connection Arrow (Mobile hidden, Desktop visible) */}
            <div className="hidden md:flex justify-center z-10">
              <Zap className="w-12 h-12 text-neon-green animate-pulse" />
            </div>

            {/* Step 2 */}
            <div className="flex flex-col items-center group relative z-10">
              <div className="w-20 h-20 md:w-24 md:h-24 bg-black rounded-full border-4 border-neon-green shadow-[0_0_25px_#39FF14] flex items-center justify-center mb-4 md:mb-6 z-10 relative">
                <Database className="w-10 h-10 md:w-12 md:h-12 text-neon-green" />
                <div className="absolute inset-0 border border-neon-green rounded-full animate-ping opacity-20"></div>
              </div>
              <h3 className="text-neon-green font-bold text-lg md:text-xl mb-2">2. Tropicalización</h3>
              <p className="text-sm text-gray-400 px-4 md:px-0">Adaptamos la oferta con IA al mercado latino.</p>
            </div>

             {/* Connection Arrow (Mobile visible, Desktop hidden) */}
             <div className="flex md:hidden justify-center -my-4">
               <ArrowDown className="w-8 h-8 text-neon-green animate-bounce" />
            </div>

             {/* Connection Arrow (Mobile hidden, Desktop visible) */}
             <div className="hidden md:flex justify-center z-10">
              <Zap className="w-12 h-12 text-neon-green animate-pulse" />
            </div>

            {/* Step 3 */}
            <div className="flex flex-col items-center group relative z-10">
              <div className="w-16 h-16 md:w-20 md:h-20 bg-black rounded-full border-2 border-brand-gold shadow-[0_0_15px_#FFD700] flex items-center justify-center mb-4 md:mb-6 group-hover:scale-110 transition-transform">
                <Lock className="w-8 h-8 md:w-10 md:h-10 text-brand-gold" />
              </div>
              <h3 className="text-white font-bold text-lg md:text-xl mb-2">3. Venta Anónima</h3>
              <p className="text-sm text-gray-400 px-4 md:px-0">Escalamos con anuncios sin mostrar la cara.</p>
            </div>

          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {[
            { title: "Sin Crear Contenido", desc: "Olvídate de bailar en TikTok." },
            { title: "Sin Soporte Técnico", desc: "Entrega automática del producto." },
            { title: "Sin Inventario", desc: "El producto es 100% digital e infinito." }
          ].map((item, idx) => (
            <div key={idx} className="bg-white/5 border border-white/10 p-5 md:p-6 rounded-lg hover:border-neon-green/50 transition-colors">
              <h4 className="text-neon-green font-bold text-base md:text-lg mb-2 flex items-center gap-2">
                <div className="w-2 h-2 bg-neon-green rounded-full"></div>
                {item.title}
              </h4>
              <p className="text-gray-400 text-sm">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Solution;